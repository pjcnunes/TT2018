<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
  <link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
			<h1>Lista de Participantes</h1>
  
  <?php
	require_once('InputValidation/CBaseFormValidation.php');
	
  $ID = intval($_REQUEST['ID']);	
	
  $nomeCompleto = CBaseFormValidation::test_input($_POST['NomeCompleto']);
  $curso = CBaseFormValidation::test_input($_POST['Curso']);
  $escola = CBaseFormValidation::test_input($_POST['Escola']);
  $email = CBaseFormValidation::test_input($_POST['Email']);
  $emailRetype = CBaseFormValidation::test_input($_POST['EmailRetype']);
  $telemovel = CBaseFormValidation::test_input($_POST['Telemovel']);
  $ano = CBaseFormValidation::test_input($_POST['Ano']);
  $data = date("Y/m/d G:i:s", time());  
	
  $dbName =  'Triologia_php_mysql'; 'test';
  $dbPass = '';
  $dbUser = 'root';
  $dbHost = 'localhost';
  $dbPort = '3306';
  $dbTableName = 'participantes';
	
  try {
      $options = array(1002 => 'SET NAMES UTF8');
      $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
		  $ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $pe) {
      echo($pe->getMessage());
  }

				
	try {
			$sql = "UPDATE $dbTableName  SET NomeCompleto = :NomeCompleto, 
				Curso = :Curso, Escola = :Escola, Email = :Email, EmailRetype = :EmailRetype, 
				Telemovel = :Telemovel, Ano = :Ano, Data = :Data where ID = :ID";
      $stmt = $ligacao->prepare($sql);
      $stmt->bindParam(':NomeCompleto',$nomeCompleto);
      $stmt->bindParam(':Curso',$curso);
      $stmt->bindParam(':Escola',$escola);
      $stmt->bindParam(':Email',$email);
      $stmt->bindParam(':EmailRetype',$emailRetype);
      $stmt->bindParam(':Telemovel',$telemovel);
      $stmt->bindParam(':Ano',$ano);
      $stmt->bindParam(':Data',$data);
			$stmt->bindParam(':ID',$ID);
      $res = $stmt->execute();
			echo "<p>Inscrição alterada.</p>";			
			echo "<p><a href='Participants_lista.php'><input type='button' class='btn' value='Voltar à lista' /></a></p>";						
  } catch (PDOException $e) {
      echo $e->getMessage();
  }
  ?>
</body>
</html>