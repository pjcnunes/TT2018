<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
  <link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo' text-align: center'>
  <?php
	
  $ID = intval($_REQUEST['ID']);
	$op = $_REQUEST['op'];		// EDIT or DELETE
	if ($op == 'delete') {
	  $action = "Participants_DELETE_proc.php?ID=$ID";
		$texto_botao = 'Eliminar';
		$cor = 'red';
	} else {
		$action = "Participants_EDIT_proc.php?ID=$ID";
		$texto_botao = 'Alterar';
		$cor = 'green';
  }	

	echo "<h1>Lista de Participantes - <span style='color:$cor'>$texto_botao</span></h1>";
	
	$dbName =  'Triologia_php_mysql'; 'test';
  $dbPass = '';
  $dbUser = 'root';
  $dbHost = 'localhost';
  $dbPort = '3306';
	$dbTableName = 'participantes';
	
	try {
        $options = array(1002 => 'SET NAMES UTF8');
        $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
				$ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (PDOException $pe) {
      echo($pe->getMessage());
  }
				

  $sql = "SELECT * FROM $dbTableName WHERE ID = :ID";
  $stmt = $ligacao->prepare($sql);
  $stmt->bindParam(':ID', $ID);
  $stmt->execute();
	
  $data = date("Y/m/d G:i:s", time());
  echo "<h2>$data</h2>";
	
  if ($stmt->rowCount() > 0) {
     //fetch record
      $obj_data = $stmt->fetch(PDO::FETCH_OBJ); 
    
      $nomeCompleto = $obj_data->NomeCompleto;
      $email= $obj_data->Email;
		  $emailRetype= $obj_data->EmailRetype;
		  $telemovel= $obj_data->Telemovel;
		  $ano= $obj_data->Ano;
		  $curso= $obj_data->Curso;
		  $escola= $obj_data->Escola;
?>
    <form name='Participants' method='POST' enctype='multipart/form-data' action='<?php echo $action; ?>'>
      <table>
        <tr>
          <th class='form'>Nome Completo</th>
          <td><input class='it2' type='text' id='NomeCompleto' name='NomeCompleto' value="<?php echo $nomeCompleto; ?>"/>*
          </td>
        </tr>
        <tr>
          <th class='form'>EMail</th>
          <td><input class='it2' type='email' id='Email' name='Email' value="<?php echo $email; ?>"/>*
          </td>
        </tr>
        <tr>
          <th class='form'>EMail-Retype</th>
          <td><input class='it2' type='email' id='EmailRetype' name='EmailRetype' value="<?php echo $emailRetype; ?>"/>*
          </td>
        </tr>
        <tr>
          <th class='form'>Telemóvel</th>
          <td><input class='it2' type='number' id='Telemovel' name='Telemovel' size='12' value="<?php echo $telemovel; ?>"/>*</td>
        </tr>
        <tr>
          <th class='form'>Escola</th>
          <td>
            <input class='it2' type='text' id='Escola' name='Escola' value="<?php echo $escola; ?>"/>*
          </td>
        </tr>
       <tr>
            <th class='form'>Ano</th>
            <td>
              <select class='it2' id='Ano' name='Ano'>
                <option <?php echo $ano=='11º'?'selected':'';?>>11º</option>
                <option <?php echo $ano=='12º'?'selected':'';?>>12º</option>
              </select>*
            </td>
          </tr>
          <tr>
            <th class='form'>Curso</th>
            <td>
              <select class='it2' id='Curso' name='Curso'">
                <option <?php echo $curso=='Técnico de Eletrónica, Automação e Instrumentação'?'selected':'';?>>Técnico de Eletrónica, Automação e Instrumentação</option>
                <option <?php echo $curso=='Técnico de Gestão de Equipamentos Informáticos'?'selected':'';?>>Técnico de Gestão de Equipamentos Informáticos</option>
	          </select>*
            </td>
          </tr>
          <tr>
            <td colspan='2' style="text-align: center;">
               <a href="Participants_lista.php"><input type='button' class="btn" value='Cancelar' /></a> 
               <input type='submit' class="btn" value='<?php echo $texto_botao; ?>' />
					 </td>
          </tr>
      </table>
    </form>			
<?php
} else  {
  echo  "<p>No rows matched the query.</p>";
}
?>
</div>
	<div id='rodape'>	
		<?php include('rodape.php'); ?>
	</div>		
</div>	
</body>
</html>
