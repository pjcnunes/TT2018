<?php
	$data = date("Y/m/d G:i:s", time()); 
	echo "<p>© $data, Paulo Nunes</p>";
?>