﻿<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
require_once 'CBaseFormValidation.php';

$_JEI = 'JEI2016';
$LINK_HOME = "http://www.jei.ipg.pt/$_JEI/index.php";
$LINK_ATRAS = htmlspecialchars("Participants.php");
$msg_voltar = "<p>Clique no botão retroceder do seu browser para voltar ao formulário.</p>";
$msg_voltar = "<br /><a style='color:#45aed6; font-size:14px;' href='$LINK_HOME'>JEI'16</a>";

$op =0;
if (isset($_REQUEST['SITUACAO'])) {
    $situacao = CBaseFormValidation::test_input($_REQUEST['SITUACAO']) ;
    if (($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS')) {
        $op = 1;
    }
}
if ($op == 0)
{
    echo $msg_voltar;
    return;
}
$reg = intval(CBaseFormValidation::test_input($_REQUEST['r'])) ;
// http://www.jei.ipg.pt/JEI2016/Participants_lista_por_workshop.php?SITUACAO=INSCRITOS
//http://www.jei.ipg.pt/JEI2016/Participants_lista_por_workshop.php?SITUACAO=INSCRITOS&r=1
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="pt">
  <title>Ficha de Inscrição: Participantes: Lista</title>
  <link rel='stylesheet' type='text/css' href='estilos.css'>
  <link rel='stylesheet' type='text/css' href='estilos_lista.css'>
  <style type='text/css'>
  table.lista {border-collapse: collapse;border: solid 1px blue;background-color: #f0e68c;}
  th.lista{border: solid 1px blue;text-align:center;color:blue;padding: 4px;}
  td.lista{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513;}
  td.lista_true{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513; background-color:#77FF00;}
  th{border: solid 1px blue;text-align:left;color:blue;padding: 4px;}
  td{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513;}
  div {margin-bottom: 10px; width: 70%; padding: 10px; border: solid thin black;}

  img.button {border: 1px solid #999999;  margin: 3px; padding: 1px;}
  a:hover img.button {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  a:hover img {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  img { border: 1px solid #999999;  margin: 3px; padding: 1px;}
  </style>
</head>
<body>
  <h1>Ficha de Inscrição: Participantes</h1>
  <?php

  require_once("ParticipantsClass.php");
  require_once("ParticipanteRepository.php");
  require_once("WorkshopRepository.php");
  require_once("WorkshopSessionsRepository.php");
  require_once("CBaseFormValidation.php");

  $data = new  ParticipantsClass();
  $obj_part = new  ParticipanteRepository();
  $workshop_sessions = new WorkshopSessionsRepository();

  //include('../UserAccounts/User_Logged.php');
  //include('../UserAccounts/Administrator.php');
   
   $RR[] = 'Manha';$RR2[] = 'Manhã';
    $RR[] = 'Tarde';$RR2[] = 'Tarde';
	$total = 0;

	
	$data = date("Y/m/d G:i:s", time());
  echo $data;
  

	$wh = ''; $wh2 = '';
  if (isset($_REQUEST['SituacaoInscricao'])) {
	$SituacaoInscricao = $_REQUEST['SituacaoInscricao'];
	if ($SituacaoInscricao != 'TODOS') {
		$wh = "where SituacaoInscricao = '$SituacaoInscricao'"; 
		$wh2 = " and (SituacaoInscricao = '$SituacaoInscricao')"; 
		}
  }
	
  

 $s = "SituacaoInscricao=TODOS";
  echo "<p><a href='Participants_lista_por_workshop.php?$s'>TODAS</a></p>";
    
  $s = "SituacaoInscricao=NAO CONFIRMADA";
  echo "<p><a href='Participants_lista_por_workshop.php?$s'>NAO CONFIRMADAS</a></p>";	
	
  $s = "SituacaoInscricao=CONFIRMADA";
  echo "<p><a href='Participants_lista_por_workshop.php?$s'>CONFIRMADAS</a></p>";	
	
  $s = "SituacaoInscricao=CANCELADA";
  echo "<p><a href='Participants_lista_por_workshop.php?$s'>CANCELADAS</a></p>";



/*
  $vagas = array();
  $inscritos = array();
  $livres = array();
  $info  = array(); // 1	2	3	9	10
  $sw = "<h2>Workshops</h2> <table style='margin-left: 2em'>";
  for ($i = 1; $i <= 6; $i++) {
      $ws_id = sprintf("Workshop%d", $i);  //12 S 1
      $s = sprintf("S%d", $i);
      $session_id = "{$ws_id}Session";
      //echo "$ws_id  - $session_id <br>";
      $ws_id = $data->{$ws_id};
      $session_id = $data->{$session_id};
      //echo "$ws_id  - $session_id <br>";
      if (($ws_id > 0) && ($session_id >0)) {
          $vs = $workshop_sessions->select($ws_id, $session_id);
          $v = $vs->vagas;
          $r = $vs->vagas_reservadas;

          $vagas [$i] = $v;
          $p = $obj_part_rep->inscricoesSessao($ws_id, $session_id); // int
          $inscritos[$i] = $p;
          $livres[$i] = $v - $r - $p;

          $data_ws = $obj_ws_rep->select($ws_id);
          if ($livres[$i] <= 0) {
              $info [] = "{$data_ws->Workshop} ({$vs->DataHora})";
          }
          $sw .= "<tr><td>$i. {$data_ws->Workshop}</td> <td>{$vs->DataHora}</td></tr>";
      }
  }
  $sw .= "</table>";
*/


  // sessões
  // escrever os inscritos


$data_obj_array =  $workshop_sessions->selectActiveWorkshopsSession();
  $workshop_sessions->listAllHTML();
  $s = "";
  foreach($data_obj_array as $data) {
      $s .= "<tr>";
      $s .= "<td>$data->ID</td>  <td>$data->id_session</td>  <td>$data->id_session</td><td>$data->DataHora</td>";
      $s .= '</tr>';
  }
  echo $s;

  /*public $id_workshop;
  public $id_session;
  public $DataHora;
  public $Description;
  public $Ativo;
  public $Horario;
  public $vagas;
  public $vagas_reservadas;*/



  $NomeCompleto = $row['NomeCompleto'];
  echo "<td class='lista'>$NomeCompleto</td>";



for($i=0; $i<2; $i++) {
   $sql2 = "SELECT $RR[$i] WS, count($RR[$i]) N FROM Participants $wh $wh2 group by $RR[$i]";
  $result2 = mysql_query($sql2, $connection);
  $N2 = mysql_num_rows($result);
   if(!$result2) die("Erro, registo não efectuado: " . mysql_error());
  // echo $sql2;
  
  echo "<h1>Workshops: $RR2[$i] - SituacaoInscricao = $SituacaoInscricao</h1>";

  while($row2 = mysql_fetch_array($result2)) {
  
   $ws  = $row2['WS'];

   $sql3 = "SELECT Workshop FROM Workshops where ID='" .$ws. "'";
   // echo $sql3;
  $result3 = mysql_query($sql3, $connection);
   if(!$result3) die("Erro, registo não efectuado: " . mysql_error());
   $row3 = mysql_fetch_array($result3);
   $Workshop  = $row3['Workshop'];
	 
	 if ($Workshop == "")
	  if ($i==0)
		  $Workshop = "Participantes que não escolheram nenhum workshop de manhã.";
		else
			$Workshop = "Participantes que não escolheram nenhum workshop de tarde.";
   
   echo "<h2>$Workshop</h2>";
   
  $sql = "SELECT * FROM Participants where $RR[$i]='" .$ws. "'" .$wh2;
  $result = mysql_query($sql, $connection);
  $N = mysql_num_rows($result);

  
  echo "<p>"."Total de inscritos: ".$N."</p>";
  echo "<table class='lista'><tr>";
  echo "<th class='lista'></th>";
  echo "<th class='lista'></th>";
  echo "<th class='lista'>ID</th>";
  echo "<th class='lista'>SUBMIT_DATE</th>";
  echo "<th class='lista'>NomeCompleto</th>";
  echo "<th class='lista'>Instituicao</th>";
  echo "<th class='lista'>Profissao</th>";
  echo "<th class='lista'>Email</th>";
  // echo "<th class='lista'>EmailRetype</th>";
  // echo "<th class='lista'>Password</th>";
  // echo "<th class='lista'>PasswordRetype</th>";
  // echo "<th class='lista'>Morada</th>";
  // echo "<th class='lista'>Localidade</th>";
  // echo "<th class='lista'>CodigoPostal</th>";
  // echo "<th class='lista'>Telefone</th>";
  // echo "<th class='lista'>Telemovel</th>";
  // echo "<th class='lista'>Workshops</th>";
  // echo "<th class='lista'>Q01</th>";
  // echo "<th class='lista'>Q02</th>";
  // echo "<th class='lista'>Q03</th>";
  // echo "<th class='lista'>Q04</th>";
  // echo "<th class='lista'>Q05</th>";
  // echo "<th class='lista'>Q06</th>";
  // echo "<th class='lista'>Q07</th>";
  // echo "<th class='lista'>Q08</th>";
  // echo "<th class='lista'>Q09</th>";
  // echo "<th class='lista'>Q10</th>";
  // echo "<th class='lista'>QOutra</th>";
  // echo "<th class='lista'>Nivel</th>";
  // echo "<th class='lista'>NumberOfVisits</th>";
   echo "<th class='lista'>SituacaoInscricao</th>";
  // echo "<th class='lista'>Data</th>";
  // echo "<th class='lista'>SUBMIT DATE</th>";
  echo "<th class='lista'>$RR2[$i]</th>";
  // echo "<th class='lista'>Tarde</th>";
  echo '</tr>';
  while($row = mysql_fetch_array($result)) {
  $total ++;
  
    echo '<tr>';
    $ID  = $row['ID'];
    echo "<td class='lista'><a href='Participants_EDIT.php?ID=$ID'><img class='button' src='buttons/edit.gif'></a></td>";
    echo "<td class='lista'><a href='Participants_DELETE.php?ID=$ID'><img class='button' src='buttons/delete.gif'></a></td>";
    $ID = $row['ID'];
    echo "<td class='lista'>$ID</td>";
    $SUBMIT_DATE= $row['SUBMIT_DATE'];
    echo "<td class='lista'>$SUBMIT_DATE</td>";
    $NomeCompleto = $row['NomeCompleto'];
    echo "<td class='lista'>$NomeCompleto</td>";
    $Instituicao = $row['Instituicao'];
    echo "<td class='lista'>$Instituicao</td>";
    $Profissao = $row['Profissao'];
    echo "<td class='lista'>$Profissao</td>";
    $Email = $row['Email'];
    echo "<td class='lista'>$Email</td>";
    // $EmailRetype = $row['EmailRetype'];
    // echo "<td class='lista'>$EmailRetype</td>";
    // $Password = $row['Password'];
    // echo "<td class='lista'>$Password</td>";
    // $PasswordRetype = $row['PasswordRetype'];
    // echo "<td class='lista'>$PasswordRetype</td>";
    // $Morada = $row['Morada'];
    // echo "<td class='lista'>$Morada</td>";
    // $Localidade = $row['Localidade'];
    // echo "<td class='lista'>$Localidade</td>";
    // $CodigoPostal = $row['CodigoPostal'];
    // echo "<td class='lista'>$CodigoPostal</td>";
    // $Telefone = $row['Telefone'];
    // echo "<td class='lista'>$Telefone</td>";
    // $Telemovel = $row['Telemovel'];
    // echo "<td class='lista'>$Telemovel</td>";
    // $Workshops = $row['Workshops'];
    // echo "<td class='lista'>$Workshops</td>";
    // $Q01 = $row['Q01'];
    // echo "<td class='lista'>$Q01</td>";
    // $Q02 = $row['Q02'];
    // echo "<td class='lista'>$Q02</td>";
    // $Q03 = $row['Q03'];
    // echo "<td class='lista'>$Q03</td>";
    // $Q04 = $row['Q04'];
    // echo "<td class='lista'>$Q04</td>";
    // $Q05 = $row['Q05'];
    // echo "<td class='lista'>$Q05</td>";
    // $Q06 = $row['Q06'];
    // echo "<td class='lista'>$Q06</td>";
    // $Q07 = $row['Q07'];
    // echo "<td class='lista'>$Q07</td>";
    // $Q08 = $row['Q08'];
    // echo "<td class='lista'>$Q08</td>";
    // $Q09 = $row['Q09'];
    // echo "<td class='lista'>$Q09</td>";
    // $Q10 = $row['Q10'];
    // echo "<td class='lista'>$Q10</td>";
    // $QOutra = $row['QOutra'];
    // echo "<td class='lista'>$QOutra</td>";
    // $Nivel = $row['Nivel'];
    // echo "<td class='lista'>$Nivel</td>";
    // $NumberOfVisits = $row['NumberOfVisits'];
    // echo "<td class='lista'>$NumberOfVisits</td>";
    // $SituacaoInscricao = $row['SituacaoInscricao'];
     echo "<td class='lista'>$SituacaoInscricao</td>";
    // $Data = $row['Data'];
    // echo "<td class='lista'>$Data</td>";
    // $SUBMIT_DATE = $row['SUBMIT_DATE'];
    // echo "<td class='lista'>$SUBMIT_DATE</td>";
	$x = "$RR[$i]";
    $Manha = $row[$x];

    echo "<td class='lista'>$Manha</td>";
    // $Tarde = $row['Tarde'];
    // echo "<td class='lista'>$Tarde</td>";
    echo '</tr>';
  }
  echo '</table>';
  }
  }
   echo "<h1>"."Certificados: ".$total."</h1>";

  include('../DataBase/data_base_close.php');
  ?>
</body>
</html>
