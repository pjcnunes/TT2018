<?php
/**
 * User: pnunes
 * Date: 19-03-2016
 * Time: 15:19
 */

header('Content-Type: text/html; charset=utf-8');
require_once('../InputValidation/CBaseFormValidation.php');


$link_email = 'http://www.jei.ipg.pt';

$_JEI = "Trilogia da Tecnologia - 4ª Edição";
$LINK_HOME = "$link_email /$_JEI/index.php";
$msg_voltar = "<br /><a style='color:#45aed6; font-size:14px;' href='$LINK_HOME'>$_JEI 	</a>";
$jei = <<<_END
<p style="margin-bottom:1em;font-size: 24pt;color:#64686d;'><a class="navbar-brand" href="$link_email/">
    <span style="color:#45aed6; font-weight: 600; font-family: 'Roboto', sans-serif;">$_JEI</a></p>
_END;

$msg = '';
if ((isset($_REQUEST['Username'])) && (isset($_REQUEST['Password']))) {
    // o utilizador já carregou no botão login
    $UsernameForm = CBaseFormValidation::test_input($_REQUEST['Username']);
    $PasswordForm = CBaseFormValidation::test_input($_REQUEST['Password']);
    $PasswordForm = sha1($PasswordForm);



    include_once 'UserAccountsRepository.php';
    include_once 'UserAccountsClass.php';
    $u_rep = new UserAccountsRepository();
    //$u_rep ->geraBind();



    $ud = new UserAccountsClass();
    $ud = $u_rep->getUserData($UsernameForm, $PasswordForm);



    if ($ud === null) {  // incorreto
        $u_rep->updateIncorrectLogin($UsernameForm);
        $msg = '<p>Autenticação sem sucesso.</p>';
    } else {             // correto
        //foreach ($ud as $k => $v) echo "$k - $v <br>";
        if (($UsernameForm === $ud->Username) && ($PasswordForm === $ud->Password)&& (1 === intval($ud->IsAproved))) {
            // inicia sessao, guarda o nome do utilizador e as permissões.
            session_start();
            $_SESSION['Nome'] = $ud->Nome;
            $_SESSION['Nivel'] = $ud->Nivel;
            $u_rep->updateNumberOfVisits($UsernameForm);

            echo "<p>Autenticação efetuada com sucesso.</p>";
            echo '<p>Redirect in 2 sec.</p>';
            if (intval($ud->Nivel) === 1) {
                header("Refresh: 1; url=ParticipantsTorneioList.php?SITUACAO=INSCRITOS&r=1247895");
            } else {
                if (intval($ud->Nivel) === 2) {
                    header("Refresh: 1; url=AccessRegisterList.php?SITUACAO=INSCRITOS&r=0");
                } else {
                    header("Refresh: 1; url=login.php");
                }
            }
        }
    }
} //else  {       // primeira vez que a página é mostrada
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta name="description" content="JEI'2018">
    <meta name="author" content="Intituto Politécnico da Guarda">
    <title>Jornadas de Engenharia Informática 2018 | IPG</title>

    <style type='text/css'>
        input.btn  {
            font-size: 12pt;
            min-width: 20em;
            background-color: #45aed6;
            border-radius: 8px;
            border: #eeeeee solid 2px;;
            color: white;
            padding: 15px 4px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin-right: 2px;
        }

        input.btn:hover  {
            background-color: #186fff;
        }

        input.it3, select.it3 {
            border-color: gray;
            border-width: 1px;
            border-style: solid;
            margin-right: 3px;
            margin-left: 3px;
            margin-bottom: 5px;
            padding: 3px;
            border-radius: 5px;
            height: 2.2em;
            width: 20em;
            font-size: 12pt;
        }

        input.it3:focus, select.it3:focus {
            border-color: #45aed6;
            box-shadow: 0 0 10px blue;
        }

        th.it3 {
            border: none;
            text-align: center;
            padding: 4px;
            background-color: white;
            vertical-align: middle;
        }
        th.it4 {
            border: none;
            text-align: center;
            padding: 4px;
            color: #45aed6;
            background-color: white;
        }

        td {
            border: none;
            text-align: left;
            padding: 4px;
            background-color: white;
            vertical-align: middle;
        }

        td.center {
            text-align: center;
        }

        h1 {
            font-size: 18pt;
            color: black;
            margin: 0;
            font-variant: small-caps;
            margin-bottom: 10px;
        }

        h2 {
            font-size: 14pt;
            color: black;
            margin: 0;
            margin-top: 20px;
            font-variant: small-caps;
            margin-bottom: 10px;
        }

        th.form {
            font-size: 12pt;
            text-align: left;
            vertical-align: middle;
        }
        div.login {
            width: 600px;
            margin: auto;
        }


    </style>
    <script>

        function EnviaDados(op){
                 return true;
        }
    </script>
</head>
<body>

<!--<img src="images/log_efatura.jpg" height="300px"/>-->
<div class="login">
    <?php echo $jei; ?>
</div>
<hr />
<div class="login">
<form name='UserAccounts' onsubmit='return EnviaDados(1);' method='POST' enctype='multipart/form-data' action=''>
    <table>
        <tr>

            <th class='it3'>Utilizador</th>
            <td><input class='it3' type='email' id='Username' name='Username' size='40'  title="Insira um E-Mail válido"
                       placeholder="E-Mail" value='' autofocus="true" aria-required="true" aria-describedby="Username-error"/>
            <!--    <i id="Username-error" class="error">Campo obrigatório</i>-->
            </td>
        </tr>
        <tr>
            <th class='it3'>Palavra passe</th>
            <td><input class='it3' type='password' id='Password' name='Password' size='40' value='' placeholder="Senha de acesso" aria-describedby="Password-error"/>
               <!-- <i id="Password-error" class="error">Campo obrigatório</i>-->
            </td>

            </td>
        </tr>

       <!-- <tr>
            <th class='it3'>Captcha</th>
            <td></td>
        </tr>-->
        <tr>
            <td colspan="2" style="text-align: center; height:1em;">
	    		<p id='resultado_validacao' style='color: ;'><?php echo $msg; ?></p>
    		</td>
        </tr>
        <tr>
            <td></td>
            <td  style="text-align: center;">
                <input type='submit' class="btn" value='Entrar' onclick="EnviaDados(0);"/>
            </td>
        </tr>
        <tr>
            <td class='it3'></td> <td class='it4' style="font-size: small; padding-top: 2em">
                <div style="float: left"><a href="RecuperarSenha.php">Recuperar Senha</a></div>
                <div style="float: right"><a href="NovoUtilizador.php">Novo Utilizador</a></div>
            </td>
        </tr>
    </table>
</div>
</form>
</body>
</html>
