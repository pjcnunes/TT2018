<?php

/**
 * Created by PhpStorm.
 * User: pnunes
 * Date: 15-03-2016
 * Time: 09:55
 */

class CBaseFormValidation
{
    static public function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
}
?>



