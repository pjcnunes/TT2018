<?php
/**
 * User: pnunes
 * Date: 01/04/16
 * Time: 23:12
 */
require('fpdf/fpdf.php');

class FolhasPresencaPDF extends FPDF
{
    // http://www.fpdf.org/
    // $pdf->Write(5,"To find out what's new in this tutorial, click ");

    function Header()
    {
        $Ratio = 2.0;
        $WW = 1565.0;
        $HH = 440.0;
        $WW = $WW / $Ratio;
        $HH = $HH / $Ratio;
        //$this->Image('images/ESTG_simb.08.jpg', 30, 95, $WW, $HH);

        $this->SetMargins(20, 20, 20);
        $this->SetFont('Times', 'B', 20);
        //Cell(float w, float h, string txt, mixed border, int ln, string align, boolean fill, mixed link)
        $this->SetTextColor(0, 61, 107);
        $this->SetFillColor(0, 0, 0);
        $w = "PRESENÇAS";
        $w = utf8_decode($w);
        $Left = $this->GetStringWidth($w);
        $Left = (210 - $Left) / 2;
        $this->SetXY($Left, 45);
        $this->Cell(150, 10, $w, 0, 0, 'L', false);
        $this->Ln();
        $this->Ln(20);

        // Image(string file [, float x [, float y [, float w [, float h [, string type [, mixed link]]]]]])
        $this->Image('images/logo.png', 40, 10, 130, 33);

        $data = date("Y/m/d G:i:s", time());  // $data = date("Y/m/d G:i:s", time());
        $this->SetTitle(utf8_decode('Trilogia da Tecnologia - 4ª Edição - Agrupamento de Escolas de Gouveia'));
        $this->SetAuthor("Workshop PHP, MySQL, E-Mail e PDF");
        $this->SetDisplayMode('real');
        $this->SetSubject(utf8_decode('Folhas de presença'));


    }

    function Table($header, $data, $w, $a, $total_lines)
    {
         //a$ = array('L','C','R');	// align
        // Colors, line width and bold font
        $this->SetFillColor(255, 255, 255);
        $this->SetTextColor(0);
        $this->SetDrawColor(69, 174, 214);
        $this->SetLineWidth(.1);
        $this->SetFont('', 'B', 10);
        // Header

        $this->SetFillColor(238, 238, 238);
        $this->SetTextColor(0);
        $this->SetFont('');
        // Data
        $fill = false;
        $a = 8;
        $this->Ln();
        $this->Ln(2);
        $d = 0;
        $this->SetFont('', 'B',  $a);
        $this->Cell(8, $a, utf8_decode("Nº"), 'LRTB', 0, 'C');
        $this->Cell(20, $a, "ID", 'LRTB',0, 'C');
        $this->Cell(70, $a, "Nome", 'LRTB');
        $this->Cell(70, $a, "Assinatura", 'LRTB');
        $this->Ln();
        $this->SetFont("");
        foreach ($data as $row) {
            //MultiCell(float w, float h, string txt [, mixed border [, string align [, int fill]]])
            if ($row != "") {
                $d++;
                $this->Cell(8, $a, number_format($d), 'LRTB', 0, 'C');
                $this->Cell(20, $a, utf8_decode($row[0]), 'LRTB',0, 'C');
                $this->Cell(70, $a, utf8_decode($row[1]), 'LRTB');
                $this->Cell(70, $a, $row[2], 'LRTB');
                $this->Ln();
                //$fill = !$fill;
                //if ($fill) $this->SetFillColor(0, 0, 0); else $this->SetFillColor(200, 200, 200);
            }
        }

        if ($d == 0) $d++;
        for (; $d <= $total_lines; $d++) {
            $this->Cell(8, $a, number_format($d), 'LRTB', 0, 'C');
            $this->Cell(20, $a, '', 'LRTB');
            $this->Cell(70, $a, '', 'LRTB');
            $this->Cell(70, $a, '', 'LRTB');
            $this->Ln();
        }
        // Closing line
        // $this->Cell(array_sum($w),0,'','T');
        $this->Ln();

    }

    public function ProducePDF0($File_Name, $workshop, $orador, $datahora, $lista_array, $total_lines)
    {
        $this->AddPage();

        //Cell(float w, float h, string txt, mixed border, int ln, string align, boolean fill, mixed link)
        $this->SetTextColor(0, 61, 107);
        $this->SetFillColor(0, 0, 0);

        $w = utf8_decode($workshop);
        $this->SetFont('', 'B', 18);
        $Left = $this->GetStringWidth($w);
        $Left = (210 - $Left) / 2;
        $this->SetXY($Left, 48);
        $this->Cell(150, 20, $w, 0, 0, 'L', false);
        // $this->Ln();


        $this->SetFont('', 'B', 18);
        $w = utf8_decode($orador);
        $Left = $this->GetStringWidth($w);
        $Left = (210 - $Left) / 2;
        $this->SetXY($Left, 55);
        $this->Cell(150, 20, $w, 0, 0, 'L', false);
        //$this->Ln();


        $w = utf8_decode($datahora);
        $this->SetFont('', 'B', 12);
        $Left = $this->GetStringWidth($w);
        $Left = (210 - $Left) / 2;
        $this->SetXY($Left, 65);
        $this->Cell(150, 12, $w, 0, 0, 'L', false);
        // $this->Ln();

        $this->Table('head', $lista_array, 180, 'L', $total_lines);
        $this->Cell(50, 10, utf8_decode("C-Confirmada, NC-Não corfirmada"), 0, 0, 'L', false);

    }

    public function ProducePDF($File_Name, $workshop, $orador, $datahora, $lista_array, $total_lines)
    {
        $this->ProducePDF0($File_Name, $workshop, $orador, $datahora, $lista_array, $total_lines);
        $this->Output($File_Name, "F");
    }

}

$dbName = 'Triologia_php_mysql';
$dbPass = '';
$dbUser = 'root';
$dbHost = 'localhost';
$dbPort = '3306';
$dbTableName = 'participantes';

try {
    $options = array(1002 => 'SET NAMES UTF8');
    $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
    $ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $pe) {
    echo($pe->getMessage());
}

$where = '';
$subTitulo = "Todas";
if (isset($_GET['op'])) {
    if ($_GET['op'] == 'C') {
        $where = "where SituacaoInscricao = 'CONFIRMADA'";
        $subTitulo = "Confirmadas";
    } else if ($_GET['op'] == 'NC') {
        $where = "where SituacaoInscricao = 'NAO CONFIRMADA'";
        $subTitulo = "Não confirmadas";
    }
}

$sql = "SELECT * FROM $dbTableName $where order by NomeCompleto desc";
$stmt = $ligacao->prepare($sql);
$res = $stmt->execute();
$data = date("Y/m/d G:i:s", time());
echo "<h2>$data</h2>";

$matriz_inscritos = array();

if ($stmt->rowCount() > 0) {
    //fetch records
    while ($obj_data = $stmt->fetch(PDO::FETCH_OBJ)) {
        if ($obj_data->SituacaoInscricao == "CONFIRMADA") {
            $sit = 'C';
        } else {
            $sit = 'NC';
        }
        $matriz_inscritos [] = array($obj_data->ID, $obj_data->NomeCompleto, $sit, "");
    }
}

$File_Name = 'FolhasPresenca.PDF';
$workshop = "PHP, MySQL, E-Mail e PDF ($subTitulo)";
$orador = 'Paulo Nunes';
$datahora = '2018-05-10 09H15';
$total_lines = 20;
$pdf = new FolhasPresencaPDF("P", "mm", "A4");
// $matriz_inscritos 3 colunas
$pdf->ProducePDF($File_Name, $workshop, $orador, $datahora, $matriz_inscritos, $total_lines);

header("Refresh: 0; url=$File_Name");

?>


