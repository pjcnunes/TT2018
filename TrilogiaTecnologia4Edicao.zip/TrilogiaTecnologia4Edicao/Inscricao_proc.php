<?php
/**
 * Created by PhpStorm.
 * User: pnunes
 * Date: 17/04/2018
 * Time: 17:41
 */

$NomeCompleto = $_POST['NomeCompleto'];
$EMail = $_POST['EMail'];
$SituacaoInscricao = 'NAO CONFIRMADA';
$data =  date("Y/m/d G:i:s", time());
$ReferenciaConfirmacao = sha1($data . $EMail);

$dbName = 'test';
$dbPass = '';
$dbUser = 'root';
$dbHost = 'localhost';
$dbPort = '3306';
$dbTableName = 'participantes';

try {
    $options = array(1002 => 'SET NAMES UTF8');
    $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
    $ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $pe) {
    echo($pe->getMessage());
}

// Criar base de dados
$dbName = 'jei2018_php_mysql';
$sql = "CREATE database IF NOT EXISTS $dbName";
$stmt = $ligacao->prepare($sql);
$stmt->execute();
$ligacao->exec("use $dbName");

$stmt = $ligacao->prepare("DROP TABLE IF EXISTS $dbTableName");
$stmt->execute();

$sql = "CREATE TABLE IF NOT EXISTS $dbTableName  (
        ID int(6) NOT NULL AUTO_INCREMENT,
        SUBMIT_DATE timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        NomeCompleto varchar(60)  NOT NULL,
        EMail varchar(40)  NOT NULL,
        SituacaoInscricao varchar(30)  NOT NULL DEFAULT 'NAO CONFIRMADA',
        ReferenciaConfirmacao varchar(200)  NOT NULL,
        PRIMARY KEY (ID)
    );";
$stmt = $ligacao->prepare($sql);
$stmt->execute();


$res = null;
try {
    $sql = "INSERT INTO $dbTableName  (NomeCompleto, EMail, SituacaoInscricao, ReferenciaConfirmacao)
	  VALUES (:NomeCompleto, :EMail, :SituacaoInscricao, :ReferenciaConfirmacao)";
    $stmt = $ligacao->prepare($sql);
    $stmt->bindParam(':NomeCompleto', $NomeCompleto);
    $stmt->bindParam(':EMail', $EMail);
    $stmt->bindParam(':SituacaoInscricao', $SituacaoInscricao );
    $stmt->bindParam(':ReferenciaConfirmacao', $ReferenciaConfirmacao );
    $res = $stmt->execute();
} catch (PDOException $pe) {
    die($pe->getMessage());
    $res = false;
}

echo "<h1>Dados da inscrição.</h1>";
echo "<p>Data              : $data<p>";
echo "<p>Nome              : $NomeCompleto<p>";
echo "<p>E-Mail            : $EMail<p>";
echo "<p>SituacaoInscricao : $SituacaoInscricao<p>";
echo "<p>Referencia Confirmacao : $ReferenciaConfirmacao <p>";

if ($res == false) {
    echo "<h1 style='color:red'>A inscrição não foi efetuada.</h1>";
    echo "<h2>Apresenta as seguintes incorreções .... </h2>";
} else {
    echo "<h1 style='color:green'>A inscrição efetuada com sucesso.</h1>";
}
?>
<a href='Inscricoes_listar.php'>Lista de inscritos</a>

