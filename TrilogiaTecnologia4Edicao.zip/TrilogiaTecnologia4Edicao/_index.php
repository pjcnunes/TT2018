<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
			<h1>Trilogia da Tecnologia - 4ª Edição</h1>
			<p>O Agrupamento de Escolas de Gouveia, vai promover a 4ª edição da “Trilogia da Tecnologia”, um evento de cariz tecnológico dirigido a todos os estudantes, desde o 1.ºCiclo do Ensino Básico até ao 12.ºano que tenham gosto, apetência e vontade de adquirir competências no domínio da tecnologia, nomeadamente da informática, robótica e eletrónica. </p>
		</div>
		<div id='rodape'>	
			<?php include('rodape.php'); ?>
		</div>		
	</div>	
</body>
</html>






