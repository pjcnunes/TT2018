<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
<?php
/**
 * Created by PhpStorm.
 * User: pnunes
 * Date: 17/04/2018
 * Time: 18:11
 */



$dbName = 'jei2018_php_mysql';
$dbPass = '';
$dbUser = 'root';
$dbHost = 'localhost';
$dbPort = '3306';
$dbTableName = 'participantes';

try {
    $options = array(1002 => 'SET NAMES UTF8');
    $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
    $ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $pe) {
    echo($pe->getMessage());
}

$where = '';
$op = '?op=ALL';
if (isset($_GET['op'])) {
    $op = 'A';
    if ($_GET['op'] == 'C') {
        $where = "where SituacaoInscricao = 'CONFIRMADA'";
        $op = '?op=C';
    } else if ($_GET['op'] == 'NC') {
        $where = "where SituacaoInscricao = 'NAO CONFIRMADA'";
        $op = '?op=NC';
    }
}
$sql = "SELECT * FROM $dbTableName $where order by SUBMIT_DATE desc";
$stmt = $ligacao->prepare($sql);
$res = $stmt->execute();
$data = date("Y/m/d G:i:s", time());
echo "<h2>$data</h2>";

if ($stmt->rowCount() > 0) {
    //fetch records
    echo "<h1>Inscritos ordenado por data</h1>";
    echo "<p><a href='FolhasPresencaPDF.php$op'>PDF</a></p>";
    echo "<h2>" . "Total de Inscritos: {$stmt->rowCount()}</h2>";
    echo "<table class='lista' style='text-align: center; width: 95%; margin: auto'><tr>";
    echo "<th class='lista'>ID</th>";
    echo "<th class='lista'>Data</th>";
    echo "<th class='lista'>Nome</th>";
    echo "<th class='lista'>Email</th>";
    echo '</tr>';

    while ($obj_data = $stmt->fetch(PDO::FETCH_OBJ)) {
        echo '<tr>';
        echo "<td class='lista'>{$obj_data->ID}</td>";
        echo "<td class='lista'>{$obj_data->SUBMIT_DATE}</td>";
        echo "<td class='lista'>{$obj_data->NomeCompleto}</td>";
        echo "<td class='lista'>{$obj_data->EMail}</td>";
        echo '<tr>';
    }
    echo '<tr>';
} else {
    print "No rows matched the query.";
}
?>
</table>