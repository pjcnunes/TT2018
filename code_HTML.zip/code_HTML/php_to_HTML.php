<?php


    function highlight_file_with_line_numbers($file) { 
          //Strip code and first span
        $code = substr(highlight_file($file, true), 36, -15);
        //Split lines
        $lines = explode('<br />', $code);
        //Count
        $lineCount = count($lines);
        //Calc pad length
        $padLength = strlen($lineCount);
        
        //Re-Print the code and span again
        $s = "<code><span style=\"color: #000000\">";
        
        //Loop lines
        foreach($lines as $i => $line) {
            //Create line number
            $lineNumber = str_pad($i + 1,  $padLength, '0', STR_PAD_LEFT);
            //Print line
            $s .= sprintf('<br><span style="color: #999999">%s | </span>%s', $lineNumber, $line);
        }
        
        //Close span
        $s .= "</span></code>";
        return $s;
    }

$files = array('cabecalho.php',
'FolhasPresencaPDF.php',
'head.php',
'_index.php',
'menu.php',
'Participants.php',
'Participants_Confirm.php',
'Participants_DELETE_proc.php',
'Participants_EDIT_DELETE.php',
'Participants_EDIT_proc.php',
'Participants_lista.php',
'Participants_proc.php',
'rodape.php',
'admin/AccessRegisterList.php',
'admin/Administrator.php',
'admin/login.php',
'admin/logout.php',
'admin/User_logged.php',
'InputValidation/CBaseFormValidation.php',
'css/estilos_lista.css',
'css/estilos.css',
'css/login.css',
'Inscricao.php',
'Inscricao_proc.php',
'Inscricoes_listar.php',
) ;
    

foreach ($files as $file2) {
    $file = "C:/xampp711/htdocs/TrilogiaTecnologia4Edicao/$file2";
    $s = highlight_file_with_line_numbers($file);
    echo "$file\n";
    $myfile = fopen($file2 . ".html", "wt") or die("Unable to open file!");
    fprintf($myfile, "%s", $s);
    fclose($myfile); 
}
    
//show_source($file);


